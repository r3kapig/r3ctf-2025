from charm.toolbox.enum import Enum

libs = Enum('openssl', 'gmp', 'pbc', 'miracl', 'relic')

pairing_lib=libs 
ec_lib=libs 
int_lib=libs 
