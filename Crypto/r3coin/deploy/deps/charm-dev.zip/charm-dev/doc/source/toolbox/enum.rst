
enum
=========================================
.. automodule:: enum
    :show-inheritance:
    :members:
    :undoc-members:
