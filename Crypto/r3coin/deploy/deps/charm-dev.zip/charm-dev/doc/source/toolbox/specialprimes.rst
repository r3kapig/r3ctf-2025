
specialprimes
=========================================
.. automodule:: specialprimes
    :show-inheritance:
    :members:
    :undoc-members:
