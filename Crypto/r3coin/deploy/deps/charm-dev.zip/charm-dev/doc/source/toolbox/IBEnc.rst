
IBEnc
=========================================
.. automodule:: IBEnc
    :show-inheritance:
    :members:
    :undoc-members:
