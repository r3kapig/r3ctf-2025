
sigma2
=========================================
.. automodule:: sigma2
    :show-inheritance:
    :members:
    :undoc-members:
